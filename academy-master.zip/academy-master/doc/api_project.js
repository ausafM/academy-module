define({
  "name": "Mavel",
  "version": "1.0.1",
  "description": "API documentation for Mavel",
  "apidoc": "0.3.0",
  "engines": {
    "node": ">=8.11.1"
  },
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-04-22T05:12:26.387Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
