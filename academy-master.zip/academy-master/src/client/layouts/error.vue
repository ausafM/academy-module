<template>
  <section class="container">
    <p>Error</p>
  </section>
</template>
<script>
export default {
  props: ['error']
};
</script>
