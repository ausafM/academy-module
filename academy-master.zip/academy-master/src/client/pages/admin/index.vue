<template>
  <p>dashboard</p>
</template>

<script>
  export default {
    middleware: 'auth',
    layout: 'admin'
  };
</script>
