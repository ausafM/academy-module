export * as courseRouteProps from './router';
export * as courseController from './controller';
export * as courseModel from './course.model';

