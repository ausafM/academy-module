export * as filesRouteProps from './router';
export * as filesController from './controller';
export * as filesModel from './files.model';

