[![forthebadge](https://forthebadge.com/images/badges/built-with-love.svg)](https://forthebadge.com)
[![forthebadge](https://forthebadge.com/images/badges/built-by-developers.svg)](https://forthebadge.com)
[![forthebadge](https://forthebadge.com/images/badges/built-for-android.svg)](https://forthebadge.com)
[![forthebadge](https://forthebadge.com/images/badges/made-with-javascript.svg)](https://forthebadge.com)

[![MIT Licence](https://badges.frapsoft.com/os/mit/mit.png?v=103)](https://opensource.org/licenses/mit-license.php)
[![dependencies Status](https://david-dm.org/boennemann/badges/status.svg)](https://david-dm.org/boennemann/badges)
[ ![Codeship Status for smitray/academy](https://app.codeship.com/projects/eef001b0-28c3-0136-75fe-76a6822b7e65/status?branch=master)](https://app.codeship.com/projects/287165)

# Academy - LMS

### Documentation

[Gitlab pages](http://smitray.gitlab.io/academy/)
